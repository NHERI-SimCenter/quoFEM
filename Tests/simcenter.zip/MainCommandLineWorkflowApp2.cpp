#include <stdio.h>
#include <LocalApplication.h>
#include <WorkflowAppWidget.h>
#include <MainWindowWorkflowApp.h>
#include "MainCommandLineWorkflowApp2.h"

#include <QObject>
#include <QString>
#include <QJsonObject>
#include <QTranslator>
#include <QEventLoop>
#include <QApplication>

MainCommandLineWorkflowApp2::MainCommandLineWorkflowApp2(MainWindowWorkflowApp *w)
  : window(w)
{

}

MainCommandLineWorkflowApp2::~MainCommandLineWorkflowApp2()
{

}

int MainCommandLineWorkflowApp2::parseAndRun(int argc, char **argv)
{
  window->loadFile(*(new QString(argv[1])));
  return runLocal();
}

int MainCommandLineWorkflowApp2::runLocal(void)
{
    QEventLoop loop;
    // LocalApplication* localApp = window->inputWidget->getLocalApp();
    QObject::connect(window->inputWidget, &WorkflowAppWidget::sendLocalRunComplete, window, &MainWindowWorkflowApp::onExitButtonClicked);
    QObject::connect(window->inputWidget, &WorkflowAppWidget::sendLocalRunComplete, &loop, &QEventLoop::quit );
    // Q_ASSERT(QObject::connect(window->inputWidget, &WorkflowAppWidget::sendLocalRunComplete, []{ exit(0); }));
    // QObject::connect(window->inputWidget, &WorkflowAppWidget::runComplete, QCoreApplication::instance(), &QCoreApplication::quit);
    window->onRunButtonClicked();

    return loop.exec();
    // exit(0);

    // return -1;
}

