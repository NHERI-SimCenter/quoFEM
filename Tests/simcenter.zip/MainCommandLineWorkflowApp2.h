// #include <QObject>
// #include <QWidget>
// #include <QString>
// #include <WorkflowAppWidget.h>
// #include <RemoteService.h>

class MainWindowWorkflowApp;

class MainCommandLineWorkflowApp2 {
  // Q_OBJECT

public:
    MainCommandLineWorkflowApp2(MainWindowWorkflowApp *windowApp);
    ~MainCommandLineWorkflowApp2();

  int parseAndRun(int argc, char **argv);
  int runLocal(void);

private:
  MainWindowWorkflowApp *window;
};

