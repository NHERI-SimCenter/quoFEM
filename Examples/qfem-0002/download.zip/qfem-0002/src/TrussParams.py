# set some parameters

E = 205
P = 25
Ao = 250
Au = 500