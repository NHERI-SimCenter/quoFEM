
Forward Propagation - FEAP
==========================

