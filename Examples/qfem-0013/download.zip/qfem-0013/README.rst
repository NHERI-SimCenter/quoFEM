
Shear wall calibration
======================

